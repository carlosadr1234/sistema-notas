# Sistema de Notas

Projeto da atividade prática de Qualidade de Software.

O projeto utiliza Python e testes automatizados com pytest.

## Funcionamento

- Calcula a média de duas notas.
- Classifica o aluno como Aprovado, Recuperação ou Reprovado.
- Executa testes automaticamente pelo GitHub Actions.
