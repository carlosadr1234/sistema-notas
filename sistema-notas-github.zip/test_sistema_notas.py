from sistema_notas import calcular_media, verificar_situacao


def test_calcular_media():
    assert calcular_media(8, 6) == 7


def test_aprovado():
    assert verificar_situacao(8) == "Aprovado"


def test_recuperacao():
    assert verificar_situacao(6) == "Recuperação"


def test_reprovado():
    assert verificar_situacao(4) == "Reprovado"
